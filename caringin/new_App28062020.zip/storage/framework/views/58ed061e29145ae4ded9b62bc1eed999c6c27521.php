<?php if($message = Session::get('pass')): ?>
<div class="alert alert-success alert-block" id="pass-alert">
        <strong>Success! </strong><?php echo e($message); ?>

</div>
<?php endif; ?><?php /**PATH D:\UIN\Kerja Praktik\App\Practical-Work\caringin\resources\views/admin/message.blade.php ENDPATH**/ ?>