<?php
    $role = Session::get('role');
?>



<?php $__env->startSection('content'); ?>
        <!-- Begin Page Content -->
        <div class="container-fluid ">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-center mb-4">
            <h1 class="h3 mb-0 text-gray-800">Data Tempat Usaha</h1>
          </div>

          <!-- Data LAPORAN -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="h-3 m-0 font-weight-bold text-primary">Tabel Tempat Usaha</h6>
            </div>
            <div class="card-body">
              <div class="form-group">
                <!--Option Menu-->
                <label for="sel1">Tampilkan Data :</label>
                <ul class="nav nav-tabs" role="tablist">
                  <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#home">Semua</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#menu1">Air Bersih</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#menu2">Listrik</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#menu3">IPK & Keamanan</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#menu4">Kebersihan</a>
                  </li>
                </ul>
                <!-- Tab panes -->
                <div class="tab-content">
                  <!--SEMUA-->
                  <div id="home" class="container tab-pane active"><br>
                  <div class="table-responsive">
                  <table class="table table-bordered" id="tableTempat" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Action</th>
                      <th>Kode Kontrol</th>
                      <th>Pemilik</th>
                      <th>Pengguna</th>
                      <th>No. Los</th>
                      <th>Jumlah Unit</th>
                      <th>Bentuk Usaha</th>
                      <th>No. Meter Listrik</th>
                      <th>Daya Listrik (W)</th>
                      <th>No. Meter Air</th>
                      <th>Tarif IPK</th>
                      <th>Tarif Keamanan</th>
                      <th>Tarif Kebersihan</th>
                    </tr>
                  </thead>

                  <tbody>
                  <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td class="text-center">
                        <a href="<?php echo e(url('updatetempat',[$data->ID_TEMPAT])); ?>" class="d-none d-sm-inline-block btn btn-primary btn-sm shadow-sm"><i
                            class="fas fa- fa-sm text-white-50"></i>Update</a>
                      </td>
                      <td class="text-left"
                      <?php if($data->STT_CICIL==0){ ?> style="color:green;" <?php } ?>
                      <?php if($data->STT_CICIL==1){ ?> style="color:red;" <?php } ?>>
                      <?php echo e($data->KD_KONTROL); ?>

                      </td>
                      <td class="text-left"><?php echo e($data->NM_PEMILIK); ?></td>
                      <td class="text-left"><?php echo e($data->NM_NASABAH); ?></td>
                      <td class="text-center"><?php echo e($data->NO_ALAMAT); ?></td>
                      <td class="text-center"><?php echo e($data->JML_ALAMAT); ?></td>
                      <td class="text-left">
                      <?php if($data->BENTUK_USAHA == null): ?>
                        (kosong)
                      <?php else: ?>
                        <?php echo e($data->BENTUK_USAHA); ?>

                      <?php endif; ?>
                    </td>
                      <td class="text-center">
                      <?php if($data->ID_TRFLISTRIK != null): ?>
                        <?php if($data->NOMTR_LISTRIK == null): ?>
                          0
                        <?php else: ?>
                          <?php echo e($data->NOMTR_LISTRIK); ?>

                        <?php endif; ?>
                      <?php else: ?>
                        &mdash;
                      <?php endif; ?>
                      </td>
                      <td class="text-center">
                      <?php if($data->DAYA == null): ?>
                        &mdash;
                      <?php else: ?>
                        <?php echo e($data->DAYA); ?>

                      <?php endif; ?>
                      </td>
                      <td class="text-center">
                      <?php if($data->ID_TRFAIR != null): ?>
                        <?php if($data->NOMTR_AIR == null): ?>
                          0
                        <?php else: ?>
                          <?php echo e($data->NOMTR_AIR); ?>

                        <?php endif; ?>
                      <?php else: ?>
                        &mdash;
                      <?php endif; ?>
                      </td>
                      <td>
                      <?php if($data->ID_TRFIPK == null): ?>
                        &mdash;
                      <?php else: ?>
                        <?php echo e($data->TRF_IPK); ?>

                      <?php endif; ?>
                      </td>
                      <td>
                      <?php if($data->ID_TRFKEAMANAN == null): ?>
                        &mdash;
                      <?php else: ?>
                        <?php echo e($data->TRF_KEAMANAN); ?>

                      <?php endif; ?>
                      </td>
                      <td>
                      <?php if($data->ID_TRFKEBERSIHAN == null): ?>
                        &mdash;
                      <?php else: ?>
                        <?php echo e($data->TRF_KEBERSIHAN); ?>

                      <?php endif; ?>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                  </table>
                  </div>
                  </div>
                  <!--END SEMUA-->
                  <!--Air-->
                  <div id="menu1" class="container tab-pane fade"><br>
                  <div class="table-responsive">
                  <table class="table display table-bordered" id="tableAir" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Tanggal</th>
                      <th>Kode Kontrol</th>
                      <th>Nama Nasabah</th>
                      <th>No. Meter Air</th>
                      <th>Bentuk Usaha</th>
                    </tr>
                  </thead>
                 
                  <tbody>
                  <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataA): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($dataA->ID_TRFAIR != null): ?>
                    <tr>
                      <td class="text-center"><?php echo e($dataA->TGL_TEMPAT); ?></td>
                      <td class="text-center"><?php echo e($dataA->KD_KONTROL); ?></td>
                      <td class="text-left"><?php echo e($dataA->NM_NASABAH); ?></td>
                      <td class="text-center">
                      <?php if($dataA->NOMTR_AIR == null): ?>
                          0
                      <?php else: ?>
                          <?php echo e($dataA->NOMTR_AIR); ?>

                      <?php endif; ?>
                      </td>
                      <td class="text-left"><?php echo e($dataA->BENTUK_USAHA); ?></td>
                    </tr>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                  </table>
                  </div>
                  </div>
                  <!--END Air-->
                  <!--Listrik-->
                  <div id="menu2" class="container tab-pane fade"><br>
                  <div class="table-responsive">
                  <table class="table display table-bordered" id="tableListrik" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Tanggal</th>
                      <th>Kode Kontrol</th>
                      <th>Nama Nasabah</th>
                      <th>Daya (W)</th>
                      <th>No. Meter Listrik</th>
                      <th>Bentuk Usaha</th>
                    </tr>
                  </thead>
                 
                  <tbody>
                  <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataL): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($dataL->ID_TRFLISTRIK != null): ?>
                    <tr>
                      <td class="text-center"><?php echo e($dataL->TGL_TEMPAT); ?></td>
                      <td class="text-center"><?php echo e($dataL->KD_KONTROL); ?></td>
                      <td class="text-left"><?php echo e($dataL->NM_NASABAH); ?></td>
                      <td class="text-left"><?php echo e($dataL->DAYA); ?></td>
                      <td class="text-center">
                      <?php if($dataL->NOMTR_LISTRIK == null): ?>
                          0
                      <?php else: ?>
                          <?php echo e($dataL->NOMTR_LISTRIK); ?>

                      <?php endif; ?>
                      </td>
                      <td class="text-left"><?php echo e($dataL->BENTUK_USAHA); ?></td>
                    </tr>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                  </table>
                  </div>
                  </div>
                  <!--END Listrik-->
                  <!--Keamanan-->
                  <div id="menu3" class="container tab-pane fade"><br>
                  <div class="table-responsive">
                  <table class="table display table-bordered" id="tableKeamanan" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Tanggal</th>
                      <th>Kode Kontrol</th>
                      <th>Nama Nasabah</th>
                      <th>Tarif IPK (Rp.)</th>
                      <th>Tarif Keamanan (Rp.)</th>
                      <th>Bentuk Usaha</th>
                    </tr>
                  </thead>
                 
                  <tbody>
                  <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataK): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($dataK->ID_TRFKEAMANAN != null && $dataK->ID_TRFIPK != null): ?>
                    <tr>
                      <td class="text-center"><?php echo e($dataK->TGL_TEMPAT); ?></td>
                      <td class="text-center"><?php echo e($dataK->KD_KONTROL); ?></td>
                      <td class="text-left"><?php echo e($dataK->NM_NASABAH); ?></td>
                      <td><?php echo e($dataK->TRF_IPK); ?></td>
                      <td><?php echo e($dataK->TRF_KEAMANAN); ?></td>
                      <td class="text-left"><?php echo e($dataK->BENTUK_USAHA); ?></td>
                    </tr>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                  </table>
                  </div>
                  </div>
                  <!--END Keamanan-->
                  <!--Kebersihan-->
                  <div id="menu4" class="container tab-pane fade"><br>
                  <div class="table-responsive">
                  <table class="table display table-bordered" id="tableKebersihan" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Tanggal</th>
                      <th>Kode Kontrol</th>
                      <th>Nama Nasabah</th>
                      <th>Tarif Kebersihan (Rp.)</th>
                      <th>Bentuk Usaha</th>
                    </tr>
                  </thead>
                 
                  <tbody>
                  <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataB): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($dataB->ID_TRFKEBERSIHAN != null): ?>
                    <tr>
                      <td class="text-center"><?php echo e($dataB->TGL_TEMPAT); ?></td>
                      <td class="text-center"><?php echo e($dataB->KD_KONTROL); ?></td>
                      <td class="text-left"><?php echo e($dataB->NM_NASABAH); ?></td>
                      <td><?php echo e($dataB->TRF_KEBERSIHAN); ?></td>
                      <td class="text-left"><?php echo e($dataB->BENTUK_USAHA); ?></td>
                    </tr>
                  <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                  </table>
                  </div>
                  </div>
                  <!--END Kebersihan-->
                </div>
                <!--END Tab Panes-->
              </div>
            </div>
          </div>
        </div>
        <!-- /.container-fluid -->
      </div>
      <!-- End of Main Content -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make( $role == 'Super Admin' ? 'admin.layout' : 'normal.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UIN\Kerja Praktik\App\Practical-Work\caringin\resources\views/admin/tempat-usaha.blade.php ENDPATH**/ ?>