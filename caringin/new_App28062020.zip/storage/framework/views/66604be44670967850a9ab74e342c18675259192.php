<?php $__env->startSection('content'); ?>
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-center mb-4">
            <h1 class="h3 mb-0 text-gray-800">Data Tagihan</h1>
          </div>

          <!-- Data LAPORAN -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="h-3 m-0 font-weight-bold text-primary"><?php echo e($dataset->NM_NASABAH); ?> <?php echo e($dataset->NO_ANGGOTA); ?></h6>
            </div>
            
            <form id="action" name="action" action="<?php echo e(url('checkout/tagihan',[$dataset->ID_NASABAH])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table display table-bordered" id="tableTagihan1" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Pilih</th>
                      <th>Lunas</th>
                      <th>Tanggal</th>
                      <th>Kode Kontrol</th>
                      <th>Tagihan Air (Rp.)</th>
                      <th>Tagihan Listrik (Rp.)</th>
                      <th>Tagihan IPK & Keamanan (Rp.)</th>
                      <th>Tagihan Kebersihan (Rp.)</th>
                      <th>Total Tagihan (Rp.)</th>
                      <th>Realisasi (Rp.)</th>
                      <th>Selisih (Rp.)</th>
                      <th>Denda (Rp.)</th>
                      <th>Ket</th>
                    </tr>
                  </thead>

                  <tbody>
                  <?php $__currentLoopData = $dataTagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataT): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($dataT->STT_LUNAS==0): ?>
                    <tr>
                      <td class="text-center">
                      <input type="checkbox" id="checkBox" name="check[]" value="<?php echo e($dataT->ID_TAGIHANKU); ?>">
                      </td>
                      <td class="text-center" 
                      <?php if($dataT->STT_LUNAS==0){ ?> style="color:red;" <?php } ?>
                      <?php if($dataT->STT_LUNAS==1){ ?> style="color:green;" <?php } ?>>
                      <?php if($dataT->STT_LUNAS == 1): ?>
                        Lunas
                      <?php else: ?>
                        Belum Lunas
                      <?php endif; ?>
                      </td>
                      <td class="text-center"><?php echo e($dataT->TGL_TAGIHAN); ?></td>
                      <td class="text-center"><?php echo e($dataT->KD_KONTROL); ?></td>
                      <td>
                      <?php if($dataT->TTL_AIR == null): ?>
                        0
                      <?php else: ?>
                        <?php echo e(number_format($dataT->TTL_AIR)); ?>

                      <?php endif; ?>
                      </td>
                      <td>
                      <?php if($dataT->TTL_LISTRIK == null): ?>
                        0
                      <?php else: ?>
                        <?php echo e(number_format($dataT->TTL_LISTRIK)); ?>

                      <?php endif; ?>
                      </td>
                      <td>
                      <?php if($dataT->TTL_IPKEAMANAN == null): ?>
                        0
                      <?php else: ?>
                        <?php echo e(number_format($dataT->TTL_IPKEAMANAN)); ?>

                      <?php endif; ?>
                      </td>
                      <td>
                      <?php if($dataT->TTL_KEBERSIHAN == null): ?>
                        0
                      <?php else: ?>
                        <?php echo e(number_format($dataT->TTL_KEBERSIHAN)); ?>

                      <?php endif; ?>
                      </td>
                      <td>
                      <?php if($dataT->TTL_TAGIHAN == null): ?>
                        0
                      <?php else: ?>
                        <?php echo e(number_format($dataT->TTL_TAGIHAN)); ?>

                      <?php endif; ?>
                      </td>
                      <td><?php echo e(number_format($dataT->REALISASI)); ?></td>
                      <td><?php echo e(number_format($dataT->SELISIH)); ?></td>
                      <td><?php echo e(number_format($dataT->DENDA)); ?></td>
                      <td class="text-center"><?php echo e($dataT->KET); ?></td>
                    </tr>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
            <div style="margin-left:35px;margin-bottom:35px;">
                <input name="button" type="submit" class="btn btn-primary" value="Checkout">
            </div>
            </form>
            <!-- End Tables -->
          </div>
          <!-- END Data LAPORAN -->
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
$(document).ready(function () {
  $(
      '#tableTagihan1'
    ).DataTable({
      "processing": true,
      "bProcessing":true,
      "language": {
        'loadingRecords': '&nbsp;',
        'processing': '<i class="fas fa-spinner"></i>'
      },
      "scrollX": true,
      "scrollY": "400px",
      "scrollCollapse": true,
      "bSortable": false,
      "deferRender": true,
      "paging":false
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('kasir.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UIN\Kerja Praktik\App\Practical-Work\caringin\resources\views/kasir/all-tagihan.blade.php ENDPATH**/ ?>