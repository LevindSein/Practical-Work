<?php
    $role = Session::get('role');
?>



<?php $__env->startSection('content'); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-center mb-4">
            <h1 class="h3 mb-0 text-gray-800">Data Nasabah</h1>
          </div>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Tabel Data Nasabah</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive ">
                <table class="table table-bordered" id="dataNasabah" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Nama Nasabah</th>
                      <th>No. Anggota</th>
                      <th>No. KTP</th>
                      <th>No. NPWP</th>
                      <th>No. Telp</th>
                      <th>Action</th>
                    </tr>
                  </thead>

                  <tbody>
                  <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td class="text-left"><?php echo e($data->NM_NASABAH); ?></td>
                      <td class="text-left"><?php echo e($data->NO_ANGGOTA); ?></td>
                      <td class="text-left"><?php echo e($data->NO_KTP); ?></td>
                      <td class="text-left"><?php echo e($data->NO_NPWP); ?></td>
                      <td class="text-left"><?php echo e($data->NO_TLP); ?></td>
                      <td class="text-center">
                        <a href="<?php echo e(url('updatenasabah',[$data->ID_NASABAH])); ?>" class="d-none d-sm-inline-block btn btn-primary btn-sm shadow-sm"><i
                            class="fas fa- fa-sm text-white-50"></i>Update</a>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make( $role == 'Super Admin' ? 'admin.layout' : 'normal.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UIN\Kerja Praktik\App\Practical-Work\caringin\resources\views/admin/data-nasabah.blade.php ENDPATH**/ ?>