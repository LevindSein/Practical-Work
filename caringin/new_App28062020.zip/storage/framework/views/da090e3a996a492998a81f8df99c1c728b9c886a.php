<?php $__env->startSection('content'); ?>
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-center mb-4">
            <h1 class="h3 mb-0 text-gray-800">Laporan Bulanan</h1>
          </div>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Tabel Laporan Bulanan</h6>
            </div>
            <div class="card-body">
            <!-- <form onsubmit="setDate()" action="<?php echo e(url('filterbulanan')); ?>" method="POST" id="bln"> -->
            <form action="<?php echo e(url('showlaporanbulanan/filter')); ?>" method="GET" id="bln">
              <label>Filter Bulan</label>
              <?php echo csrf_field(); ?>
              <input type="month" name="filterbln" id="" class="form-control form-control-user" style="width:20%">
              <br><button type="submit" class="btn btn-primary btn-sm">Submit</button><p>
            </form>
              <div class="form-group">
                <label for="sel1">Tampilkan Data :</label>
                <ul class="nav nav-tabs" role="tablist">
                  <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#home">Air Bersih</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#menu1">Listrik</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#menu2">IPK & Keamanan</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#menu3">Kebersihan</a>
                  </li>
                </ul>
                <!-- Tab panes -->
                <div class="tab-content">
                  <!--AIR BERSIH-->
                  <div id="home" class="container tab-pane active"><br>
                  <div class="table-responsive">
                  <table class="table display table-bordered" id="tableAir" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Status</th>
                      <th>Bulan</th>
                      <th>Kode</th>
                      <th>Nama Nasabah</th>
                      <th>M.Lalu</th>
                      <th>M.baru</th>
                      <th>Pakai (M<sup>3</sup>)</th>
                      <th>B.Pemakaian (Rp.)</th>
                      <th>B.Beban (Rp.)</th>
                      <th>B.Pemeliharaan (Rp.)</th>
                      <th>B.Air Kotor (Rp.)</th>
                      <th>Pembayaran (Rp.)</th>
                      <th>Realisasi (Rp.)</th>
                      <th>Selisih (Rp.)</th>
                      <th>Denda (Rp.)</th>
                      <th>Ket</th>
                    </tr>
                  </thead>

                  <tbody>
                  <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($d->ID_TRFAIR != null): ?>
                    <tr>
                      <td class="text-center"
                      <?php if($d->STT_LUNAS==0){ ?> style="color:red;" <?php } ?>
                      <?php if($d->STT_LUNAS==1){ ?> style="color:green;" <?php } ?>>
                      <?php if($d->STT_LUNAS == 1): ?>
                        Lunas
                      <?php else: ?>
                        Belum Lunas
                      <?php endif; ?>
                      </td>
                      <td class="text-center"
                      <?php $time = date("Y - M", strtotime($d->TGL_TAGIHAN)); ?>>
                      <?php echo e($time); ?>

                      </td>
                      <td class="text-left"><?php echo e($d->KD_KONTROL); ?></td>
                      <td class="text-left"><?php echo e($d->NM_NASABAH); ?></td>
                      <td><?php echo e(number_format($d->AWAL_AIR)); ?></td>
                      <td><?php echo e(number_format($d->AKHIR_AIR)); ?></td>
                      <td><?php echo e(number_format($d->PAKAI_AIR)); ?></td>
                      <td><?php echo e(number_format($d->BYR_AIR)); ?></td>
                      <td><?php echo e(number_format($d->BYR_BEBAN)); ?></td>
                      <td><?php echo e(number_format($d->BYR_PEMELIHARAAN)); ?></td>
                      <td><?php echo e(number_format($d->BYR_ARKOT)); ?></td>
                      <td><?php echo e(number_format($d->TTL_AIR)); ?></td>
                      <td><?php echo e(number_format($d->REALISASI_AIR)); ?></td>
                      <td><?php echo e(number_format($d->SELISIH_AIR)); ?></td>
                      <td><?php echo e(number_format($d->DENDA_AIR)); ?></td>
                      <td class="text-left">
                      <?php if($d->KET == null): ?>
                        &mdash;
                      <?php else: ?>
                        <?php echo e($d->KET); ?>

                      <?php endif; ?>
                      </td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                  </table>
                  </div>
                  </div>
                  <!--END AIR BERSIH-->
                  <!--LISTRIK-->
                  <div id="menu1" class="container tab-pane fade"><br>
                  <div class="table-responsive">
                  <table class="table display table-bordered nowrap" id="tableListrik" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Status</th>
                      <th>Bulan</th>
                      <th>Kode</th>
                      <th>Nama Nasabah</th>
                      <th>Daya (W)</th>
                      <th>M.Lalu</th>
                      <th>M.baru</th>
                      <th>Pakai (kWh)</th>
                      <th>Rek.Min (Rp.)</th>
                      <th>B.Blok 1 (Rp.)</th>
                      <th>B.Blok 2 (Rp.)</th>
                      <th>B.Beban (Rp.)</th>
                      <th>BPJU (Rp.)</th>
                      <th>Pembayaran (Rp.)</th>
                      <th>Realisasi (Rp.)</th>
                      <th>Selisih (Rp.)</th>
                      <th>Denda (Rp.)</th>
                      <th>Ket</th>
                    </tr>
                  </thead>

                  <tbody>
                  <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($d->ID_TRFLISTRIK != null): ?>
                    <tr>
                    <td class="text-center"
                      <?php if($d->STT_LUNAS==0){ ?> style="color:red;" <?php } ?>
                      <?php if($d->STT_LUNAS==1){ ?> style="color:green;" <?php } ?>>
                      <?php if($d->STT_LUNAS == 1): ?>
                        Lunas
                      <?php else: ?>
                        Belum Lunas
                      <?php endif; ?>
                      </td>
                      <td class="text-center"
                      <?php $time = date("Y - M", strtotime($d->TGL_TAGIHAN)); ?>>
                      <?php echo e($time); ?>

                      </td>
                      <td class="text-left"><?php echo e($d->KD_KONTROL); ?></td>
                      <td class="text-left"><?php echo e($d->NM_NASABAH); ?></td>
                      <td><?php echo e(number_format($d->DAYA_LISTRIK)); ?></td>
                      <td><?php echo e(number_format($d->AWAL_LISTRIK)); ?></td>
                      <td><?php echo e(number_format($d->AKHIR_LISTRIK)); ?></td>
                      <td><?php echo e(number_format($d->PAKAI_LISTRIK)); ?></td>
                      <td><?php echo e(number_format($d->REK_MIN)); ?></td>
                      <td><?php echo e(number_format($d->B_BLOK1)); ?></td>
                      <td><?php echo e(number_format($d->B_BLOK2)); ?></td>
                      <td><?php echo e(number_format($d->B_BEBAN)); ?></td>
                      <td><?php echo e(number_format($d->BPJU)); ?></td>
                      <td><?php echo e(number_format($d->TTL_LISTRIK)); ?></td>
                      <td><?php echo e(number_format($d->REALISASI_LISTRIK)); ?></td>
                      <td><?php echo e(number_format($d->SELISIH_LISTRIK)); ?></td>
                      <td><?php echo e(number_format($d->DENDA_LISTRIK)); ?></td>
                      <td class="text-left">
                      <?php if($d->KET == null): ?>
                        &mdash;
                      <?php else: ?>
                        <?php echo e($d->KET); ?>

                      <?php endif; ?>
                      </td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                  </table>
                  </div>
                  </div>
                  <!--END LISTRIK-->
                  <!--IPK & KEAMANAN-->
                  <div id="menu2" class="container tab-pane fade"><br>
                  <div class="table-responsive">
                  <table class="table display table-bordered" id="tableKeamanan" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Status</th>
                      <th>Bulan</th>
                      <th>Blok</th>
                      <th>Nama Nasabah</th>
                      <th>Alamat</th>
                      <th>Jumlah Unit</th>
                      <th>Total (Rp.)</th>
                      <th>Realisasi (Rp.)</th>
                      <th>Selisih (Rp.)</th>
                    </tr>
                  </thead>
                 
                  <tbody>
                  <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($d->ID_TRFIPK != null || $d->ID_TRFKEAMANAN != null): ?>
                    <tr>
                    <td class="text-center"
                      <?php if($d->STT_LUNAS==0){ ?> style="color:red;" <?php } ?>
                      <?php if($d->STT_LUNAS==1){ ?> style="color:green;" <?php } ?>>
                      <?php if($d->STT_LUNAS == 1): ?>
                        Lunas
                      <?php else: ?>
                        Belum Lunas
                      <?php endif; ?>
                      </td>
                      <td class="text-center"
                      <?php $time = date("Y - M", strtotime($d->TGL_TAGIHAN)); ?>>
                      <?php echo e($time); ?>

                      </td>
                      <td class="text-center"><?php echo e($d->BLOK); ?></td>
                      <td class="text-left"><?php echo e($d->NM_NASABAH); ?></td>
                      <td class="text-center"><?php echo e($d->NO_ALAMAT); ?></td>
                      <td class="text-center"><?php echo e($d->JML_ALAMAT); ?></td>
                      <td><?php echo e(number_format($d->TTL_IPKEAMANAN)); ?></td>
                      <td><?php echo e(number_format($d->REALISASI_IPKEAMANAN)); ?></td>
                      <td><?php echo e(number_format($d->SELISIH_IPKEAMANAN)); ?></td>
                    </tr>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                  </table>
                  </div>
                  </div>
                  <!--END IPK&KEAMANAN-->
                  <!--KEBERSIHAN-->
                  <div id="menu3" class="container tab-pane fade"><br>
                  <div class="table-responsive">
                  <table class="table display table-bordered" id="tableKebersihan" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Status</th>
                      <th>Bulan</th>
                      <th>Blok</th>
                      <th>Nama Nasabah</th>
                      <th>Alamat</th>
                      <th>Jumlah Unit</th>
                      <th>Total (Rp.)</th>
                      <th>Realisasi (Rp.)</th>
                      <th>Selisih (Rp.)</th>
                    </tr>
                  </thead>
                 
                  <tbody>
                  <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($d->ID_TRFKEBERSIHAN != null): ?>
                    <tr>
                    <td class="text-center"
                      <?php if($d->STT_LUNAS==0){ ?> style="color:red;" <?php } ?>
                      <?php if($d->STT_LUNAS==1){ ?> style="color:green;" <?php } ?>>
                      <?php if($d->STT_LUNAS == 1): ?>
                        Lunas
                      <?php else: ?>
                        Belum Lunas
                      <?php endif; ?>
                      </td>
                      <td class="text-center"
                      <?php $time = date("Y - M", strtotime($d->TGL_TAGIHAN)); ?>>
                      <?php echo e($time); ?>

                      </td>
                      <td class="text-center"><?php echo e($d->BLOK); ?></td>
                      <td class="text-left"><?php echo e($d->NM_NASABAH); ?></td>
                      <td class="text-center"><?php echo e($d->NO_ALAMAT); ?></td>
                      <td class="text-center"><?php echo e($d->JML_ALAMAT); ?></td>
                      <td><?php echo e(number_format($d->TTL_KEBERSIHAN)); ?></td>
                      <td><?php echo e(number_format($d->REALISASI_KEBERSIHAN)); ?></td>
                      <td><?php echo e(number_format($d->SELISIH_KEBERSIHAN)); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                  </table>
                  </div>
                  </div>
                  <!--END KEBERSIHAN-->
                </div>
                <!--END Tab Panes-->
              </div>
            </div>
          </div>
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UIN\Kerja Praktik\App\Practical-Work\caringin\resources\views/admin/laporan-bulanan.blade.php ENDPATH**/ ?>