<?php
    $role = Session::get('role');
?>



<?php $__env->startSection('content'); ?>
       <!-- Begin Page Content -->
       <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-center">
          <h1 class="h3 mb-0 text-gray-800">Update Nasabah</h1>
        </div>

        <div class="row justify-content-center">
          <div class="col-lg-6">
            <div class="p-4">
            <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form class="user" action="<?php echo e(url('update/store',[$data->ID_NASABAH])); ?>" method="POST">
              <?php echo csrf_field(); ?>
                <div class="form-group">
                  Nama Nasabah
                  <input value="<?php echo e($data->NM_NASABAH); ?>" style="text-transform: capitalize;" required type="text" name="nama" class="form-control form-control-user" id="exampleInputNamaNasabah" placeholder="Nama">
                </div>
                <div class="form-group">
                  Nomor Anggota
                  <input readonly value="<?php echo e($data->NO_ANGGOTA); ?>" type="number" name="ktp" class="form-control form-control-user" id="exampleInputNomorKtp" placeholder="321xxxxx">
                </div>
                <div class="form-group">
                  Nomor KTP Nasabah
                  <input value="<?php echo e($data->NO_KTP); ?>" type="number" name="ktp" class="form-control form-control-user" id="exampleInputNomorKtp" placeholder="321xxxxx">
                </div>
                <div class="form-group">
                  Nomor NPWP Nasabah
                  <input value="<?php echo e($data->NO_NPWP); ?>" type="text" name="npwp" class="form-control form-control-user" id="exampleInputNpwpPelanggan" placeholder="99xxxxx">
                </div>
                <div class="form-group">
                  Nomor Telpon
                  <input value="<?php echo e($data->NO_TLP); ?>" required type="number" name="telpon" class="form-control form-control-user" id="exampleInput" placeholder="0818xxxxx">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <button type="submit" class="btn btn-primary btn-user btn-block">Simpan</button>
              </form>
              
            </div>
          </div>
        </div>
      </div>
    <!-- End of Main Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make( $role == 'Super Admin' ? 'admin.layout' : 'normal.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UIN\Kerja Praktik\App\Practical-Work\caringin\resources\views/admin/update-nasabah.blade.php ENDPATH**/ ?>