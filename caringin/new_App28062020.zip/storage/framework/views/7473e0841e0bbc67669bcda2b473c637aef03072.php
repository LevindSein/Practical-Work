<?php $__env->startSection('content'); ?>
<?php
$id = implode(",",$ids);
?>

       <!-- Begin Page Content -->
       <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-center">
          <h1 class="h3 mb-0 text-gray-800">Checkout</h1>
        </div>

        <div class="row justify-content-center">
          <div class="col-lg-6">
            <div class="p-4">
            <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form class="user" action="<?php echo e(url('printfaktur',[$id])); ?>" method="POST">
              <?php echo csrf_field(); ?>
                <div class="form-group">
                  Nama Nasabah
                  <input readonly value="<?php echo e($dataku->NM_NASABAH); ?>" class="form-control form-control-user">
                </div>
                <div class="form-group">
                  No. Anggota
                  <input readonly value="<?php echo e($dataku->NO_ANGGOTA); ?>" class="form-control form-control-user">
                </div>
                <div class="form-group">
                  Tagihan Air
                  <input readonly value="Rp. <?php echo e(number_format($d->ttlAir)); ?>" class="form-control form-control-user">
                </div>
                <div class="form-group">
                  Denda Air
                  <input readonly value="Rp. <?php echo e(number_format($d->dendaAir)); ?>" class="form-control form-control-user">
                </div>
                <div class="form-group">
                  Tagihan Listrik
                  <input readonly value="Rp. <?php echo e(number_format($d->ttlListrik)); ?>" class="form-control form-control-user">
                </div>
                <div class="form-group">
                  Denda Listrik
                  <input readonly value="Rp. <?php echo e(number_format($d->dendaListrik)); ?>" class="form-control form-control-user">
                </div>
                <div class="form-group">
                  Tagihan IPK & Keamanan
                  <input readonly value="Rp. <?php echo e(number_format($d->ttlIpkeamanan)); ?>" class="form-control form-control-user">
                </div>
                <div class="form-group">
                  Tagihan Kebersihan
                  <input readonly value="Rp. <?php echo e(number_format($d->ttlKebersihan)); ?>" class="form-control form-control-user">
                </div>
                <div class="form-group">
                  Total Tagihan
                  <input readonly value="Rp. <?php echo e(number_format($d->ttlTagihan + $d->dendaAir + $d->dendaListrik)); ?>" class="form-control form-control-user">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <button type="submit" class="btn btn-primary btn-user btn-block" name="bayar[]" value="<?php echo e($id); ?>">Bayar</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    <!-- End of Main Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('kasir.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UIN\Kerja Praktik\App\Practical-Work\caringin\resources\views/kasir/checkout.blade.php ENDPATH**/ ?>