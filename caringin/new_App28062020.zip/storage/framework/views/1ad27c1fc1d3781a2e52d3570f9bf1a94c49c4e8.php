<?php $__env->startSection('content'); ?>
       <!-- Begin Page Content -->
       <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-center">
          <h1 class="h3 mb-0 text-gray-800">Ganti Alat Air</h1>
        </div>

        <div class="row justify-content-center">
          <div class="col-lg-6">
            <div class="p-4">
            <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <form class="user" action="<?php echo e(url('update/storegantialatair',[$data->ID_TEMPAT])); ?>" method="POST">
              <?php echo csrf_field(); ?>
                <div class="form-group">
                  Kode Kontrol
                  <input readonly value="<?php echo e($data->KD_KONTROL); ?>" type="text" name="kontrol" class="form-control form-control-user" id="exampleInputKode" placeholder="(kosong)">
                </div>
                <div class="form-group">
                  Nama Nasabah
                  <input readonly value="<?php echo e($data->NM_NASABAH); ?>" type="text" name="nasabah" class="form-control form-control-user" id="exampleInputNas" placeholder="(kosong)">
                </div>
                <div class="form-group">
                  ID Meteran Lama
                  <input readonly value="<?php echo e($data->ID_MAIR); ?>" type="number" name="idMAirLama" class="form-control form-control-user" id="exampleInputMAirLama" placeholder="(kosong)">
                </div>
                <div class="form-group">
                  Nomor Meteran Lama
                  <input readonly value="<?php echo e($data->NOMTR_AIR); ?>" type="text" name="noMAirLama" class="form-control form-control-user" id="exampleInputNoAirLama" placeholder="(kosong)">
                </div>
                <div class="form-group">
                  ID Meteran Baru
                  <input required type="number" name="idMBaru" class="form-control form-control-user" id="exampleInputMAirBaru" placeholder="ID Meteran ada di Data Alat">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <button type="submit" class="btn btn-primary btn-user btn-block">Simpan</button>
              </form>
              
            </div>
          </div>
        </div>
      </div>
    <!-- End of Main Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UIN\Kerja Praktik\App\Practical-Work\caringin\resources\views/admin/update-ganti-air.blade.php ENDPATH**/ ?>