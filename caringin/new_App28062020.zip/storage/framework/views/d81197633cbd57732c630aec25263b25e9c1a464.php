<?php $__env->startSection('content'); ?>
       <!-- Begin Page Content -->
  
       <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-center">
          <h1 class="h3 mb-0 text-gray-800">Tambah Tagihan</h1>
        </div>

        <div class="row justify-content-center">
          <div class="col-lg-6">
            <div class="p-4">
              <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <form class="user" action="<?php echo e(url('tagihan/store/admin',[$data->ID_TEMPAT])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  Kode Kontrol
                  <input readonly value="<?php echo e($data->KD_KONTROL); ?>" type="text" name="kode" class="form-control form-control-user" id="exampleInputKode" placeholder="A-1-001">
                </div>
                <div class="form-group">
                  Nama Nasabah
                  <input readonly value="<?php echo e($data->NM_NASABAH); ?>" type="text" name="nama" class="form-control form-control-user" id="exampleInputNama" placeholder="Fahni Amsyari">
                </div>
                <div class="form-group">
                  Bayar IPK
                  <input readonly value="Rp. <?php echo e(number_format($data->TRF_IPK)); ?>" name="bayarI" class="form-control form-control-user"
                  <?php if($data->TRF_IPK == NULL){ ?>placeholder="(kosong)" <?php } ?>>
                </div>
                <div class="form-group">
                  Bayar Keamanan
                  <input readonly value="Rp. <?php echo e(number_format($data->TRF_KEAMANAN)); ?>" name="bayarK" class="form-control form-control-user" id="exampleInputKeamanan"
                  <?php if($data->TRF_KEAMANAN == NULL){ ?>placeholder="(kosong)" <?php } ?>>
                </div>
                <div class="form-group">
                  Bayar Kebersihan
                  <input readonly value="Rp. <?php echo e(number_format($data->TRF_KEBERSIHAN)); ?>" name="bayarB" class="form-control form-control-user" id="exampleInputKebersihan"
                  <?php if($data->TRF_KEBERSIHAN == NULL){ ?>placeholder="(kosong)" <?php } ?>>
                </div>
                <div class="form-group">
                  Meter Lalu Air
                  <input readonly value="<?php echo e(number_format($data->MAKHIR_AIR)); ?>" name="laluAir" class="form-control form-control-user" id="exampleInputLaluA"
                  <?php if($data->ID_TRFAIR == NULL){ ?>placeholder="(kosong)" <?php } ?>>
                </div>
                <div class="form-group">
                  Meter Baru Air
                  <input type="text" pattern="^[\d,]+$" name="mAir" class="form-control form-control-user" id="exampleInputAir"
                  <?php if($data->ID_TRFAIR == NULL){ ?> readonly placeholder="(kosong)" <?php } ?>>
                </div>
                <div class="form-group">
                  Meter Lalu Listrik
                  <input readonly value="<?php echo e(number_format($data->MAKHIR_LISTRIK)); ?>" name="laluListrik" class="form-control form-control-user" id="exampleInputLaluL"
                  <?php if($data->ID_TRFLISTRIK == NULL){ ?>placeholder="(kosong)" <?php } ?>>
                </div>
                <div class="form-group">
                  Meter Baru Listrik
                  <input type="text" pattern="^[\d,]+$" name="mListrik" class="form-control form-control-user" id="exampleInputListrik"
                  <?php if($data->ID_TRFLISTRIK == NULL){ ?> readonly placeholder="(kosong)" <?php } ?>>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <Input type="submit" value="Tambah Tagihan" class="btn btn-primary btn-user btn-block">
              </form>      
            </div>
          </div>
        </div>
      </div>
    <!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
  document.getElementById('exampleInputAir').addEventListener('input', event =>
  event.target.value = (parseInt(event.target.value.replace(/[^\d]+/gi, '')) || 0).toLocaleString('en-US'));
</script>
<script>
  document.getElementById('exampleInputListrik').addEventListener('input', event =>
  event.target.value = (parseInt(event.target.value.replace(/[^\d]+/gi, '')) || 0).toLocaleString('en-US'));
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('normal.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\UIN\Kerja Praktik\App\Practical-Work\caringin\resources\views/normal/form-tagihan.blade.php ENDPATH**/ ?>