@extends('errors::minimal')

<!-- Begin Page Content -->
<div class="container-fluid">

<!-- 404 Error Text -->
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

@section('title', __('Not Found'))
@section('code', '404')
@section('message', __('Not Found'))
